                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:628929
3D Printed Case for Arduino Uno, Leonardo. by ZygmuntW is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

When you do your Arduino DIY projects, it is good to have a case for them.  

This is easy to print case for Arduino UNO or Leonardo.  

It is designed to print without support, there are no brigdes as well.  

Editable OpenSCAD files:  
https://github.com/zygmuntw/3D-Printed-Case-for-Arduino

If you would like to edit this model or make something similar please use the link below:
https://www.fiverr.com/p3d_lab/do-cad-parametric-modelling-for-3d-printing

Emboss a text or a logo on your 3D printed case:
https://www.fiverr.com/p3d_lab/emboss-text-or-logo-on-3d-model

# Print Settings

Printer Brand: Prusa
Printer: Prusa Clone
Rafts: No
Supports: No

# Instructions

I printed it on both Leaprog Creatr (0.35mm nozzle) and Prusa i3 (0.3mm nozzle) printers with good results using following setings:  

Layer Height - 0.25mm  
Perimeter Widht - 0.5mm  

You will need 4x Self Tapping POZI CSK screws number 4, 16mm long to put it all together.