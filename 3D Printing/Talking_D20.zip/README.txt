                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:955433
Talking D20 by adafruit is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

https://www.youtube.com/watch?v=klmxXRzAuSU
https://learn.adafruit.com/talking-d20-20-sided-gaming-die/overview  

The 20-sided die — or “d20” as it’s known to tabletop gamers — is an icon of geek culture. In this project we’ll 3D-print a jumbo d20 and outfit it with electronics…because that’s how we roll at Adafruit.  

The talking d20 is fun and good for a laugh…though with electronics inside it won’t be 100% perfectly random or balanced…so it’s not suitable for all gaming situations and doesn’t replace your trusty dice bag. Think of it as a geek version of those “executive decision maker” toys.  

The code and sounds are completely customizable. For example, you could load each of the 20 faces with the names of local lunch spots and use it to pick the day’s destination.