                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:740357
Ciclop 3D Scanner by bq3D is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Ciclop 3D Scanner is an Open Source project created by bq.  

All sources are hosted in GitHub:  

+  3D Parts: [Ciclop GitHub](https://github.com/bqlabs/ciclop)  
+  Electronics: [Zum GitHub](https://github.com/bq/zum)  
+  Software: [Horus GitHub](https://github.com/bqlabs/horus)  
+  FIrmware: [Horus-fw GitHub](https://github.com/bqlabs/horus-fw)  


You can find more information at DIWO: [[en](http://diwo.bq.com/en/tag/ciclop/)] [[es](http://diwo.bq.com/tag/ciclop/)]  



# Instructions

[![Ciclop - Building Instructions](http://img.youtube.com/vi/VYQuiM_4nls/0.jpg)](http://www.youtube.com/watch?v=VYQuiM_4nls)