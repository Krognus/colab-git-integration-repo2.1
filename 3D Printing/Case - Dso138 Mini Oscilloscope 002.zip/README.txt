                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3322112
case - DSO138 mini oscilloscope 002 by BETLOG is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

2018-12-30--14-42-55
- A case for the DSO138Mini oscilloscope. 

- The current evolution of https://www.thingiverse.com/thing:3234032 
Separated into it's own thing for simplicity.

- Supports BNC probe connector, 18650 battery pack and switch.
  - Removed the USB port access, because I should have done that weeks ago.

- IMPORTANT:
NOT the "H" version, and probably NOT clones.
Official Manual: https://jyetech.com/Products/LcdScope/UserManual_138mini.pdf shows title of "DN138-12v02" and Model: 13805K - if your DSO138 does not precisely match this model it will not fit in this case.
The model this thing is for does not have a power switch, which is why the BOM below adds one.
The model this thing is for has slightly rounded square edges on the PCB, not large trimmed corners. This should make it visually apparent which one you have.

- Print at 0.4mm nozzle, 0.2mm layers, otherwise all design tolerances will be wrong.
It is a good idea (maybe essential) to specify 0.4mm wide outer perimeters in your slicer.
PLA works fine.
Supports are required, but only because of one very tiny unsupported structure in the corner of the screen. (vis: slicer screenshots).

- NOTE: I often avoid supports by putting a thin 'skin' over  bolt penetrations. This forces supports to NOT be built in certain places. You will need to use a 2.5mm drill bit, rat-tail file, or acutely tipped blade to remove this single layer 'skin' from all of the M2.5 bolt penetrations.

- REQUIRES:
2x M3x6mm wedge-head bolt
2x M3 square nut
4x M2.5x20mm (whatever head) bolt
4x M2.5 hex nuts (if you ever find a source for square M2.5 or M2 nuts PLEASE tell me)
1x SS12F32 SPDT Slide Switch
1x BH-18650-A-09 single 18650 battery holder
1x XH female plug
~150mm small gauge insulated wire

- ASSEMBLY:
  - Solder some small gauge wire and your XH connector/SPDT switch/18650 battery holder into a harness.
  - Insert the ROLLSWITCHES into TOP. 
While holding them in with your thumb, work the knob on the opposite side back and forth to ensure smooth movement.
  - Insert the BUTTONS into TOP. 
Buttons should move very freely. If not for their entire length then at least for the last mm.
  - Insert the SPDT slide switch into the FRAME.
Note : it is intended to be a very tight fit.
  - Insert the screen (detach the mainboard first) into TOP
  - Attach short wedge/button (wedge preferred, but button should still fit) M3s through the battery holder and temporarily attach square M3 nuts only a couple of turns onto the end of bolt.
Slide M3 nuts into the slots, while also guiding your soldered terminals into the side slots of TOP.
Soldering the battery terminals on their INside face is better, but either in or outside face will fit unless you solder like a savage.
Finger tighten M3 bolts onto battery holder/TOP
  - insert FRAME into TOP and onto the back of the screen.
Arrange your wiring and it's exits to the battery/XH power connector. 
The wires from the XH power connector bend upwards and sit between the XH and USB ports after the mainboard is attached to the screen.
  - Attach main board to screen. 
Set ROLLERSWITCHES to one of their extreme positions, set the actual switches on the mainboard to match.
Lower the mainboiard onto the dupont connectors, and ensure that the switch extensions correctly penetrate the ROLLERSWITCH cavities.
I soldered my duponts very perpendicular to the boards to begin with, but after assembling and disassembling the screen/mainboard dozens of times during the design iterations of this case my dupont connectors have also been finger tweaked fit together very perfectly. So connecting the mainboard to the screen is very simple for me. However yours may require some wrangling.
  - Tighten battery holder bolts. Battery holder front face should be flush with the TOP front face.
You can also do this last; after attaching the BASE.
  - TEST
Insert battery, throw switch and test that it powers up, and that your switches behave as expected.
Note that without the BASE attached your switches may push the mainboard out when toggled, so you need to make sure the mainboard isn't getting pushed out and adversely effecting your switch response.
  - Add BASE. 
The structural strength of this part are very light, and bolt/nut tolerances on this are extremely tight, so your nut recesses need to be nice and clear of debris, and becasue a 20mm bolt is only barely long enough; you may need to coax the nut to start threading onto the bolt a bit to start with. It does however all fit perfectly.