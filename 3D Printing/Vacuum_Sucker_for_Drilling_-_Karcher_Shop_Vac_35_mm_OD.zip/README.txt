                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2963133
Vacuum Sucker for Drilling - Karcher Shop Vac 35 mm OD by Petclaud is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Thank you JonnieZG for sharing your "Vacuum Sucker for Drilling" (https://www.thingiverse.com/thing:2939576)! Great design since through the hole you still have full visibility on what you are doing, while in the same time through that hole air is sucked in, picking up the dust and then out it goes through the exit pipe into your vacuum cleaner. Due to the vacuum it creates, this 'thing' also sucks itself a bit against the wall. Overall much better than some of the 'cup-types' I have seen till date. 

_______________________________________________________________


This is not really a 'remix'. The original design is for a vacuum hose connection with an outer diameter of 30 mm. I just resized the original design accurately in Meshmixer  such that it fits perfectly on my Karcher WD 3 shop vac which has an outer diameter of 35 mm. Credits to JonnieZG.



# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: Yes
Resolution: 0.15 or 0.20
Infill: 20%

Notes: 
Print in the orientation as per the STL file and with supports ON. Suggest to use 3 or 4 perimeters, to avoid very small infills in the exit pipe.
 
Not so much supports are needed - see Slic3r screen. It will print in some 3,5 hours