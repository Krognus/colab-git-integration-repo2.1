                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:468872
Spider Rover by johann517 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This Spider Rover can be simply clicked together with one and the same lock washer type. No screws required. Just in case you want to do more extensive research with it, you can add a motor (pulley is in the files)   

https://www.youtube.com/watch?v=7VCwuc3o3bI  

Motor replications will be listed here:
Alex Korvin Workshop: https://www.youtube.com/watch?v=KnwvxoD-njw&t=56s
Ing. Alberto: https://www.youtube.com/watch?v=VS-I7gMOVA0
Justin Wilcott: https://www.youtube.com/watch?v=LswDA3t8Rc0


# Instructions

added piece count requested by pcav:  
  
1x deck_base.stl  
1x deck_bottom.stl  
1x deck_middle.stl  
1x deck_top.stl  
6x leg_arm_bottom.stl  
12x leg_arm_middle.stl  
12x leg_arm_upper.stl  
6x leg_control_al50_delta-30_r1_s1.5.stl  
6x leg_gear.stl  
6x leg_gear_washer_fix.stl  
6x leg_pin_bottom.stl  
6x leg_pin_middle.stl  
12x leg_pin_upper_middle.stl  
6x leg_shell_big.stl  
12x leg_shell_small.stl  
6x leg_shoulder.stl  
76x lock_washer.stl  
1x optional_motor_belt_pulley.stl (only for motor)  
1x worm_gear.stl (not scale, motor) or worm_gear_scaling.stl (small scaling)  
1x deck_bottom_worm_gear.stl (bearing, motor) or deck_bottom_worm_gear_dummy.stl (no bearing, no motor)  
  
To put together one leg as shown in the picture use from the complete part list:  
    
1x leg_arm_bottom.stl  
2x leg_arm_middle.stl  
2x leg_arm_upper.stl  
1x leg_control_al50_delta-30_r1_s1.5.stl  
1x leg_pin_bottom.stl  
1x leg_pin_middle.stl  
2x leg_pin_upper_middle.stl  
1x leg_shell_big.stl  
2x leg_shell_small.stl  
1x leg_shoulder.stl  
1x leg_gear_washer_fix.stl  
8x lock_washer.stl