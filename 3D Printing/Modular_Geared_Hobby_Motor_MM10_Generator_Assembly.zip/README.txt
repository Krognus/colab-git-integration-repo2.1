                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1002959
Modular Geared Hobby Motor (MM10) Generator Assembly by kwardle is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a modular assembly to sandwich together a number of small hobby motors (MM10 size).  These motors can be scavenged from all sorts of throwaway products and toys.  I took a couple of these from some vibrating toothbrushes.  Here is a video which shows the gear motion (https://youtu.be/mjIyzF06KFg) there is another on my channel which shows one motor being driven by a 9V battery.  

This assembly was designed to couple with my CD Tesla Turbine (http://www.thingiverse.com/thing:595380) and I have included a video from testing here (https://youtu.be/PvrO0FS4luE).  With the faucet on nearly full, I got only 0.5V from a single motor (last in train of 4)--since these run at 12000RPM driven at 3V, I guess that would put the motor RPM somewhere around 2000 or so.  I have not yet tried to wire these all up appropriately and link to a battery for charging, but plan to do so if I can get the total voltage up to ~5V.  I may also make a hand crank coupling to mate with with something like http://www.thingiverse.com/thing:135718.  As you can see from the second image (and perhaps the video as well), there is some serious splashing, so I may need to make a cover to protect the motors for this particular application---and I need to optimize the exit flow path of my turbine to avoid so much water coming out the shaft and getting flung everywhere on the driver gear...  

I hope someone else finds this interesting and useful.  

# Instructions

1) Print your parts  
Depending on how many motors you want to string together, you will need to print up one motor gear, module gear, gear shroud, and spacer block per motor.  Print one of each of the larger gears and one gear arm piece for the end.  Everything prints without supports.  
2) Eat some broccoli  
Well, I suppose you don't have to eat the broccoli, but you should, it's good for you.  What you really need is the thick rubber band that comes on the broccoli.  You can certainly use some other rubber band(s) but these are strong and work well.  Plus, you get to enjoy some broccoli while you wait for the prints to finish. ;-)  
3) Assemble  
I tried some designs which required no hardware (bolts/screws), but found the shafts to be almost impossible not to break.  In the end, I just used a ~1" screw (or 8-32 bolt) to hold each gear.  The motor gear fits on tight, use a hammer to tap it on by placing the gear down and hitting the back side of the motor shaft.  Have a look at the image to see how the gears and modules fit together.  Use one or more thick rubber bands to hold it all together.  
4) Wiring  
I have yet to complete this step myself.  I guess you will need to use some diodes to connect up the wiring in a way that one motor doesn't simply turn another.  Keep in mind also that adjacent motors turn opposite directions.