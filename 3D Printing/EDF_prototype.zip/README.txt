                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:218350
EDF prototype by jhsandell is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is work in progress!!!   

UPDATE: on request a set of STL are uploaded. They are only at BETA stage. Please do not ask features or corrections. Instead edit your copy of the 123D files.  

A mini electric ducted fan (EDF) designed around the E-flite BL180 - 3000KV brushless motor. Look how small it is. (2s Lipo, 2A continuous, 3A for 10 seconds max.)  

Main features are:  
1. Center of momentum - Impeller is mounted on the outside of the BL rotor. This is not common, as most EDF's use a "inrunner" motor.  
2. Load distribution - Impeller is a "pusher" and distributes the load on the whole rim of the BL rotor. If it was a "puller" it would put huge stress on the 3 screws.  

First printed impeller was running without any vibrations!!!  

Designed in Autodesk 123D.  


# Instructions

Impeller must be printed with 100% fill for strength.  
Use support material.  

My current settings:  
First layer: 0,25mm  
Next layers: 0,15mm  
PLA at 180 deg. C   
Bed at 57 deg. C  
"Slow speed" / Cooling fan with open window and freezing outside / tweaking and tweaking and tweaking of all params in Slic3r.  

PS. You might want to process the STL file in meshlab prior to slicing.