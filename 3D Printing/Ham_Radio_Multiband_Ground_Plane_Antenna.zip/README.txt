                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2030237
Ham Radio Multiband Ground Plane Antenna by ok1cdj is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is remix from http://www.thingiverse.com/thing:1725339

The idea is make 3 or 4 band lightweight  portable vertical antenna. 
The dimensions and simulations and measurements coming soon.
Work is in progress.

The holder is designed in Openscad and use cable ties. 

CHANGE LOG
------------------
#####12.1.2017 
- Added simulation of 40,20,30m version with base loading coil. 

#####13.1.2017 
- Added radial end insulator in STL and OpenSCAD

#####23.1.2017 
- Added reduction for BNC connector and cover when connector is not used

#####26.1.2017 
- Added knob for M6 nuts

#####07.2.2017 
- Coil inductance measurement

#####10.2.2017 
- Improved coil holder for better fit of cable ties

#####12.2.2017 
- Bottom fixing for fibre glass pole - 6m Decathon travel pole or cheap 6m pole Agepoch from Aliexpress.
- pole guying part for top of pole - 5mm and 10mm diameter

#####26.2.2017 
- Field  test of 40/30/20m version  with VNA, 4.1 m lenght of vertical element, 5.25m radials
  Antenna is really narrow on 40m as expected.
- Plots from VNA.

#####24.4.2017
-wiring diagram





# Print Settings

Printer: Prusa MK2
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 20%

Notes: 
Only coil and holder need support, other parts without support..