                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2045010
Y-axis rework for Anet A8 by matsekberg is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Added 2018-05-006:
So finally I uploaded the OpenSCAD files so that you guys can improve this design.

Removed 2017-04-14:
Removed the old versions, now there are files only for the latest version.
I have changed the spec for the threaded rods to 340 and 290 mm. 

Added 2017-03-23:
I remade the two endpoints by moving the screws a little bit to the left to make more room for the belt and belt mount. Also made the cylinders where the screws are inserted into less depp for a more easy assembly into the printer. The files have version number "2.1".

Added 2017-02-19: 
I have added a lower profile belt tensioner that gives 8mm more Y space in the front, file "Y-axis belt3.stl".
I have also added files for the belt mount under the heat bed, files "Y belt bedmount.stl" and "Y belt bedmount w offset.stl"

The stock design for the Y-axis on a A8 printer is not good. The Y-axis belt is clamped between the front and back of the printer. When the belt is tensioned the front and back will be bent towards each other and the Y Engine mount will rotate slightly. Also when the Y-carriage make direction changes the front and back moves a litte bit in relation to the print head and the frame. This can lead to imperfections on the print.

One solution is to print frame stabilizers to make the front/back more stiff and resilient to bend. However, the principle to have the frame cope with belt tension is wrong.

With this model I'm trying another approach, to decouple the Y-axis belt tension from the frame. The belt, roller, motor is contained in an integrated module. The belt tension is balanced by the two 6mm threaded bars and not by the frame. This module is then only attached to the back frame of the printer.
As a bonus we get a nice belt tensioner for Y.

There are two files for the belt mount under the hot bed. One to use when the hotbed H alu bracket is turned upside down (Y_belt_bedmount_w_offset.stl) and another when the H bracket is mounted with the middle section of the H downwards (Y_belt_bedmount.stl).

# Print Settings

Printer: Anet A8
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: At least 40% and 95% on belt tensioner

Notes: 
i Would strongly recommend an infill of 90% with the belt tensioner to get it strong.

You could also print the motor part with the motor mount down on the heated (thanx naifa). the model needs to be placed 0.9mm beneath Z=0 in order to flatten out the motor mount.

# Post-Printing

Remove structures (obviously).
The 6 mm holes for threaded rods might have to be drilled to dimension.
The four "pins" that is supposed to fit in the four holes of the front may need some sanding to fit.


# Instructions

## Bill of materials

1 pc. 6 mm stainless steel threaded rod, 340 mm long.
1 pc. 6 mm stainess steel threaded rod, 290 mm long.
6 pc. 6 mm stainless steel locknut.
6 pc. stainless steel washer for 6 mm screw.
1 pc. 3 mm axle or screw without head, 17 mm long.
1 pc. belt roller for GT2 belt, 16 teeth, 6 mm wide (or original roller)



## Assembly

Note that the belt mount under the bed will be removed completely since it is too bulky. You need to make a clamp of 1-2 mm metal with two holes matching the holes where the original belt was. Clamp the belt between the metal clamp and the bed with two screws and a nut.

* Cut the 6mm threaded bars into two pieces of 340 and 290 mm length
* Touch up the end on the rods where you cut
* Assemlbe the rods, the endstops, the belt roller and all nuts and wahsers as in the pictures
* Remove the Y blank rods by pulling the through the hole in the front
* Remove the belt mount and remove the bed
* Remove the stock Y motor mount
* Insert the assembled unit to its position in the printer as in the pictures
* Place the bed in place, wrap the belt around the motor axle pulley and put the belt roller in place with the 3mm axle (with the belt around it)
* Center the 6mm rods between the front and back mounts and turn the back two nuts until they rest against the back mount
* Tension the belt by moving the belt roller carriage forward and turning the nuts so that they help tensioning the belt to the desired tension
* Fasten the motor mount in the back frame using the original screw/nut that held the stock motor mount
* Turn the frontmost two nuts on the rod until they rest against the front mount, do NOT tension so that the front is pressed forward and bends. There is no need for tension here other than to prevent the front mount from being loose
* If the printer is mounted on a base plate: Fasten the motor mount to the base plate with a screw in the slotted hole on the motor mount
* You may need to check that the belt is in parallell with the blank bars, I had to move the belt roller on the Y motor axis a couple of mm away from the motor