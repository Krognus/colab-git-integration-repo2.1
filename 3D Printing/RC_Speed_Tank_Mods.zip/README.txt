                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2227184
RC Speed Tank Mods by evil_k is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is my print of Bryant87's RC Speed Tank. http://www.thingiverse.com/thing:2024364

Designed an aggressive tank tread. Only have enough links for one track so far - still printing. Shown on right side of tank. Left side is Bryant87's tank tread printed in PolyFlex. Everything else printed in PETG, including the aggressive tread links.

Tried something different on the aggressive tank tread - using 3mm ABS filament instead of the 3mmx35 bolts to hold the links together. Just used one 3mm bolt on the right track to make disassembly easier. Seems to work. Ream/clean the holes out with a 3mm drill bit. the fit on this track is very tight, so ream the center hole in the links out good.

Note: I just fried the 35t motor driving the aggressive track. Had the tank stuck nose down in a tough spot and could not turn the track. 

Made a spacer for the motor to move it away from the drive sprocket 2mm. The drive gear on the motor was in touch with the drive sprocket.

My print of the stock track links were a bit sloppy fitting. Have printed some spacer/rings to go on the front idler to increase the diameter 4mm (IdlerRing-2mm-solid). Have also included IdlerRing-2.5mm-solid to increase the diameter by 5mm if required. These fit my idler pulley snug enough without any adhesive.

Suggest use 55t motors!

Print track links with support. I printed the track link with the tread side down (it will look ugly with the support) since more important to keep the idler side smooth.

Source file for the track uploaded, along with a couple more pictures.

Burnt out one of the 35T brushed motors and have temporarily installed two SkyRC Cheetah brushless encoder motors (21.5T/1600kV) - still finding the motors too fast. For now put the 3x35mm bolts back in for connecting the track links together. Running it around outside (at half full throttle!) and motors stay cool. These motors seem good (but still too fast) but do not like the ESCs supplied with the motors.

Found some 80t 540 motors on ebay.ca - have ordered some to try out

http://www.ebay.ca/itm/GoolRC-540-80T-Brushed-Motor-for-1-10-Off-Road-Rock-Crawler-Climbing-RC-Car-Y5O9-/252834966558?hash=item3ade236c1e:g:tzgAAOSwSlBY21cn

80t motor with ESC:

http://www.ebay.ca/itm/GoolRC-540-80T-Brushed-Motor-with-40A-ESC-Combo-for-1-10-Axial-SCX10-RC-Car-D4G4-/252835041022?hash=item3ade248efe:g:ow8AAOSwc-tY22q1