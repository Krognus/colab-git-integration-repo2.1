                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1176646
Air Raid Siren - hand crank version by MlePh is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

<div>
	<strong>There's a newer version of this design:</strong><br />
	<a href="http://www.thingiverse.com/thing:1568198">Air Raid Siren - hand crank version 2</a></div>
<div>
	 </div>
<div>
	This design is 100% 3D printed. Works fine but may have friction trouble when rotating fast!</div>
<div>
	 </div>
<div>
	<span style="color:#ff0000;"><strong>Be careful when using it! Dont touch the moving parts while they are rotating!</strong></span></div>


# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator 2
Rafts: No
Supports: No
Resolution: 0.2
Infill: 10 %

Notes: 
The spaced between the moving parts are optimized for a 0.4 nozzle diameter (importend if you use MakerWare). Every part is designed to be printed without support and raft. Some parts have the support in its design. Just break it away after it is printed.

To make them more stable print the parts "_GetrAdapt" and "_Kurbel2" with more shells / infill. Rest can be printed with standard settings.

The part Schraube1 needs to be printed 3 times.
The part Schraube2 needs to be printed 6 times

# Post-Printing

The rotor-parts should be glued together.

Use some oil for the moving parts!