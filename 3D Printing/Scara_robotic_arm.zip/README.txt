                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1241491
Scara robotic arm by Idegraaf is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Scara robotic arm for educational purposes. Not tested yet.

# BOM

LM8UU bearing 4x
8x22x7 608-ZZ bearing 2x
15x32x9 6002-ZZ bearing 3x
Linear bearing rod 3x
M3 bolt 8mm 10x   for motor
M3 bolt 30mm 2x  +nut 2x
M8 bolt 40mm 1x  +nut 1x
GT2 pulley 20 teeth 2x
GT2 belt 320mm 160 teeth 1x
GT2 belt 160mm 80teeth 2x
threaded rod M8 1x 
coupling 5 to 8 1x


Update 05/01/16
Modified "arm-2" that fit better with the "arm-1".
Update 11/01/16
Added 8mm nutholder.