                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:721620
CNC Touch Probe by scorch is licensed under the Creative Commons - Public Domain Dedication license.
http://creativecommons.org/publicdomain/zero/1.0/

# Summary

This is a touch probe for a CNC machine.  The probe consists of a set of 3D printed parts and some hardware available from McMaster Carr.  The 3D printed parts do not include threads for the fasteners so they will need to be tapped prior to assembly.  The stepped boss on the top of the probe is designed to fit into either a 1/4 or 1/2 inch collet for easy mounting on the CNC machine.  

If you need some software to put your new probe to good use check out G-Code Ripper.  It will map an existing g-code file to a probed surface.  http://www.scorchworks.com/Gcoderipper/gcoderipper.html  

A lot of the designing of this part was performed on my Android phone using ScorchCAD (While traveling or waiting for my kids to be done with practice for various activities). http://www.scorchworks.com/ScorchCAD/scorchcad.html

------------------------------------

Instructions

After I assembled the probe I found that adding a very small amount of lithium grease to the interface between the shoulder screws and round head screws helped the probe return to the closed position after each probe point

For the probe tip I ground down a short length of 1/4 inch threaded rod to a point. The tip is threaded into the shaft part so I can swap it out for another tip depending on what I want to probe.

--------------

Mechanical Parts: (with McMaster-Carr Part Numbers)
91259A535 3 Each Alloy Steel Shoulder Screw, 1/4" Diameter X 3/8" Long Shoulder, 10-24 Thread

1692K58 1 Pack Type 302 Ss Conical Compression Spring, .625"l,.720" Large Od,.375" Small Od,.040" Wire

90279A148 1 Pack Znc Pltd Stl Round Head Phillip Machine Screw, 6-32 Thread, 1/2" Length

90760A007 1 Pack Zinc Plated Steel Narrow Hex Nut, 6-32 Thread Size, 1/4" Wide, 3/32" High

98032A436 1 Pack Mil Spec. Cadmium-plated Steel Flat Washer, Number 6 Screw Size, Ms-27183-43, 0.156" Id

--------------

Electrical Components:
Resistors, (3x) 12 kOhm

Transistor, BC547B

Earphone Jack (3.5 mm), Radio Shack, 274-0249
(The inverting circuit is not needed if you have your probe set up to trigger when the probe is an open circuit.)

--------------

Tools Needed:

General Purpose Tap, Thread Size 6-32 (McMaster 2522A717)

General Purpose Tap, Thread Size 1/4"-20 (McMaster 2521A621)