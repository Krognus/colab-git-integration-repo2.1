                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2755765
Updated 12 Hole Ocarina by RobSoundtrack is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Update: heres a sample video lol
https://www.youtube.com/watch?v=TvEI7b8xlbU&feature=youtu.be


I really loved the source ocarina by nimaid!

I wanted to update the instrument to make the top end more playable (high notes) without losing tone in the midrange, as it was beautiful in that area.

The voicing window, labium edge, and airway were updated to allow easy high notes, then dialed back some to regain most of the timbre that nimaid was able to create from this awesome thing.

After much reading, trial, and error, it turns out the answer wasn't too far from the original design afterall.

That's not to say I wouldn't refine this more in the future.

If you make one, please post it up!


# Print Settings

Printer: Creality CR-10
Rafts: Yes
Supports: Yes
Resolution: .2
Infill: 100%

Notes: 
I print mine at .2 layers, 100% infill (personal pref) on esun PLA pro.
Have gone as rough as .4 layers, 20% infill, 1.8mm walls with success.
Just keep a good wall size.

Print vertically, to match the thingiverse preview.