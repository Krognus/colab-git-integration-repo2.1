                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:185859
Polyhedra - Hinged Nets and Snap Tiles by mathgrrl is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

UPDATE: The modular snap-tiles in this model have now been updated to a more consistent Customizer design where you can modify size, number of snaps, and tolerances; see http://www.thingiverse.com/thing:208591.  

*****  

This entry for the Makerbot Academy Math Manipulative Challenge is a set of eight hinged polyhedral nets and five types of modular snap tiles for assembling various types of polyhedra.  

Printability:  
These models were all specifically built for and tested on the MakerBot Replicator 2.  We stayed up late at night testing, resizing, and retesting all the hinges and snaps so that teachers won't have to! Each hinged net and snap tile is made to print as easily and quickly as possible at .3mm/Low resolution with the standard MakerWare settings, without raft or supports. The hinged nets print all on one piece, fully assembled and ready to fold up. The snap tiles print as individual pieces that are all compatible with each other.  

Educational Value:  
Paper models of polyhedra and polyhedral nets are a standard part of the K-12 curriculum and college level teacher-prep courses. The hinged nets included here are sturdy and easy for students to assemble and collapse over and over without the need for tape or other connectors. The individual snap tiles allow students to explore more exotic polyhedra and make it possible for teachers to construct more complicated models for the classroom.   

Creativity:   
We created each of these models at www.tinkercad.com and have made those Tinkercad files public so that teachers and students can get creative - editing, remixing, or extending as needed. If you want tighter/looser snaps or hinges, alternate side snap configurations, or different polyhedral nets, you can easily pick apart and reassemble or resize in Tinkercad, even if you don't have much prior experience with 3D modeling.  

This set of models includes hinged nets for all five Platonic solids:  
* Tetrahedron  
* Cube  
* Octahedron  
* Dodecahedron  
* Icosahedron  

As well as hinged nets for these other polyhedra:  
* Square Pyramid  
* Hexagonal Prism  
* Rectangular Rhombohedron  

The downloadable files also include models of individual snap tiles for semi-regular and other combination polyhedra:  
* Triangle tiles with snaps in 223, 332, 222, and 333 configurations  
* Square tiles with snaps in 2323 and 2233 configurations  
* Pentagon tiles with snaps in 23233 and 32322 configurations  
* Hexagon tiles with snaps in 232323, 233233, and 322322 configurations  

Mix and match snap tiles as you like or follow these suggestions for the pictured modular polyhedra:  
* Cuboctahedron - 6 of the 2323 squares, 2 of the 222 triangles, and 6 of the 332 triangles  
* Truncated Octahedron - 6 of the 2323 squares and 8 of the 232323 hexagons  
* Stellated Octahedraon - 12 of the 223 triangles and 12 of the 332 triangles  
* Icosidodecaheron - 20 of the 332 triangles and 12 of the 32322 pentagons  

Or, make a 3D-printed soccer ball or even larger Buckyballs using the pentagon and hexagon snap tiles! For a standard soccer ball we suggest this print job:  
* Truncated icosahedron - 6 of the 23233 pentagons and 6 of the 32322 pentagons, plus 12 of the 232323 hexagons, 4 of the 233233 hexagons, and 4 of the 322322 hexagons  

Two assembly videos:  
* http://www.youtube.com/watch?v=vcxooyMfePE&feature=youtu.be  
* http://www.youtube.com/watch?v=8PBx7xQqTm8   

Read more on MakerHome, Days 80-90: 
* [Hinged Tetrahedron](http://makerhome.blogspot.com/2013/11/days-80-82-coming-soon.html)
* [Hinged Cube](http://makerhome.blogspot.com/2013/11/day-81-hinged-cube.html)
* [Hinged Octahedron](http://makerhome.blogspot.com/2013/11/day-82-hinged-octahedron.html)
* [Hinged Dodecahedron](http://makerhome.blogspot.com/2013/11/day-83-hinged-dodecahedron.html)
* [Hinged Icosahedron](http://makerhome.blogspot.com/2013/11/day-84-hinged-icosahedron.html)
* [Hinged Hexagonal Prism](http://makerhome.blogspot.com/2013/11/day-85-hexagonal-prism.html)
* [Hinged Rectangular Rhombohedron](http://makerhome.blogspot.com/2013/11/day-86-rectangular-rhombohedron.html)
* [Snap Cuboctahedron](http://makerhome.blogspot.com/2013/11/day-87-cuboctahedron.html)
* [Snap Truncated Octahedron](http://makerhome.blogspot.com/2013/11/day-88-truncated-octahedron.html)
* [Snap Icosidodecahedron](http://makerhome.blogspot.com/2013/11/day-89-icosidodecahedron.html)
* [Snap Stellated Octahedron](http://makerhome.blogspot.com/2013/11/day-90-stellated-octahedron.html)


# Instructions

MakerWare .3mm/low with standard settings.  

If you want to modify any model just grab an editable copy at Tinkercad: https://tinkercad.com/users/c4Y857uk4FJ-6d-lab .

=====

#####Twitter: [twitter.com/mathgrrl](https://twitter.com/mathgrrl)

#####Hacktastic blog: [www.mathgrrl.com/hacktastic](http://www.mathgrrl.com/hacktastic)

#####Shapeways geekhaus store: [www.shapeways.com/shops/mathgrrl](https://www.shapeways.com/shops/mathgrrl)

*This design and all associated pictures and files are licensed under the [Creative Commons Attribution Non-Commercial Share Alike](https://creativecommons.org/licenses/by-nc-sa/2.5/) license. If you want to use designs, images, or files outside of the terms of this license, please email <request@mathgrrl.com>.*