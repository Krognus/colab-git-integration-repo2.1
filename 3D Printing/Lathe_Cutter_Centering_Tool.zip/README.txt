                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1010033
Lathe Cutter Centering Tool by NeverDun is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is a tool for adjusting your cutters to the rotational axis of your lathe.  This will help to prevent breakage from facing with a tool set too high, or poor surface finish with the tool set too low, or too high.

# Instructions

The part is meant to be printed on it's back, with the bubble trough facing up.  To complete the assembly you will need:  

One 608z skateboard bearing (readily available)  

One 5/16 steel shaft about 3 inches long. I cut two circlip grooves to hold the bearing in place, but two O-rings will work just fine, and will aid in dis-assembly and flat storage.  

One 9x40mm long spirit level.  I just found these online, and they come in packs of 10:  
http://www.banggood.com/10pcs-9x40mm-Cylindrical-Bubble-Spirit-Level-Set-For-Professional-Measuring-And-Normal-Use-p-979993.html  

One 10-32 x 1 inch socket cap screw with jam nut (a 10-32 cone point set screw works excellent as a precision alternative) 

The bearing should be a light press fit into the printed part, and the spirit level pops in by hand as well. The 10-32 threads I used a tap for, and a similar metric size should work just fine too.  

To tune it to your lathe, set the flat bottom portion of the tool on your lathe cross slide parallel to the chuck face.  Turn your adjusting screw in until it just barely contacts the cross slide.  LIGHTLY tighten the jam nut. You are ready to rock!  If you are super picky, you can face the end of your screw before calibrating.  

IGES and STEP files are supplied for those who want to modify for a different Spirit level ETC.