                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3590733
Mini RC Servo Tank (REMIX) by xjedix is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a remix of Areg7's Mini RC Servo Tank: https://www.thingiverse.com/thing:3211790

Changes made:

-Narrowed the main body by 10mm
-Doubled the width of the track, now 30mm
-Fully enclosed the bottom of the body
-Added a top cover to the to the main body to fully enclose the electronics
-Minor adjustments to the inside of the body for electronics clearance
-Changed the drive wheel design for added strength and easier printing
-Added radius to the bottom edges of the main chassis
-Added radius to the side plates for better chassis ground clearance


Electronics used:

Jumper T12 radio
Flysky GR3E receiver 
Tower Pro 9g servos qty-2 (modified for continuous rotation) 
380mah 1s lipo battery

Video - https://youtu.be/J4-V4XREQ4U