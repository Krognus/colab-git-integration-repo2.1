                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1024834
Drill bit sharpener by mgx is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I've researched many existing approaches to drill bit sharpening but did not find one that I like. I like simple and utilitarian designs. This is one of those: a one-piece guide for sharpening drill bits on a Dremel or similar rotary tool that uses an M19-2 thread.

There are 3 guides included: 90, 118 and 135 degrees. The majority of people will need the 118* and for that the adapter comes in two sizes such that it can easily fit both small and large diameter drills, as well as different diameters in cutting/grinding disks.  

The adapter prints in one piece without support and is threaded to screw right onto the Dremel (I've tested it on my Dremel 285, 8000 and generic Alltrade tool which all happen to be 19mm thread size). It's also designed to accommodate mandrel upgrades.  

Addressing some comments:
*Doesn't FIT* - check your printer calibration, x/y/z steps/mm and slicer settings (filament factor or extrusion multiplier especially). Print a 20mm calibration cube and measure with precision calipers. Also check your material settings, many materials (esp ABS and PETG) tend to "tighten" when you print inside circles. Maybe resize it a bit (1-2%)?

*No Relief Angle* - Yes I'm aware of the flaw. I'm going to try to re-design it some day, I wasn't expecting this to become so popular amogst the specialized people. I was in fact aware of the drill bit geometry and relief angle at the time of the design, it's actually a bit more complex than a single angle (there is the right-hand/left-hand issue as well), but at the time decided to keep it simple and figured I'll add the relief by hand, you can actually see me doing it freehand in the video, at around 1:05-1:15. The relief angle is not as critical as the cutting edge, therefore can done by hand.

Feel free to tweak but note the non-commercial use, please contact me for a separate license if you are interested.  

Example use: https://youtu.be/Z6N5WAULoEM


# Instructions

I printed mine out of PLA, 0.2 layer, 33% infill. I printed multiple ones on multiple printers and seem to fit well, however printer calibration is critical. 

If you are worried PLA melting, then you're overheating your drill bit anyway (iow remember to quench the bits in water if they get too hot at the tip)