                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:906058
#CatchTheWind > Charge your Phone > Vertical Wind Turbine Generator by KG1610 is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

In Spirit of the competition > I wanted to make something useful ..... and started with the goal of charging my iPhone using the power of the wind.  

Immediately a turbine comes to mind.   
This Vertical Turbine will drive a generator and then charge small DC devices.   

I wanted to make it portable, you can take it anywhere and charge your phone.   

It is magnetically levitated.  The repelling magnets will handle the weight of the Rotor. Let the wind make it Turn and generate electricity.   

I can add another generator section. i.e Magnet Rotor with Coils.   

Things still to consider  

The Turbine  >   
Many different designs   
how many blades should i use ?  
Reading up on Wikipedia - i might change the Turbine.   

The Generator >   
The current design uses round coils.   
I might change this to use pie shaped winding's instead.   

Will update on progress as i go along.  

There is only one company that is selling Makerbot Machine's here in South Africa (Rectron) - I went past last week and was blown away. Makerbot is amazing.    

 Update : 2015-07-06   
I wanted to start the Build on the weekend.   
I have run into a horrible problem  .. this build I made to be the maximum size possible for my printer.  
While the model shows in the center of the print bed the actual print is not and Prints off the heated bed. ?!?  

I don't know why this is happening  - anyone run into a similar problem please let me know.   
I will sort this during the course of the week and aim to print this weekend.   


Update  : 2015-07-09  
I had to change my original design. Its a bit smaller now.   
uploaded new Files for this. I have printed the base and the coil Base and the Coils. (Uploaded Pics and new STL Files)  

Will Start the winding Tonight. :(:  

Update : 2015-07-13  
Productive sessions this weekend.   

Changed the Coil design so i could attach them to a drill   
(winding the coils by hand would have taken 45 years)  
Changed the Magnet Rotor, nicer design   i printed and completed the original one (Pic Attached) but will reprint new design   
Designed a back cover for the coil base (for all the wiring etc)  

Printed the Turbine (Pic Uploaded) (15 hour Print !?)  
Printed 6 coils and wound them.   

coming together nicely   

Update : 2015-07-14  
Printed new Rotor  
my printer is not closing off the Top layer 100 % now ?  
I increased the extrusion rate by 2 % to correct this - if anyone knows why - please let me know.   
Pics of the coil winding are up too.   

Update : 2015-07-21  
Printer has been giving me problems - have to leave it alone for a bit then give it some love. Its weird . Prints perfectly ! then not.   

its printing great again - printed the Coil Base Cover  
See pics   

The Coils are hurting me , I keep dropping them / breaking them.  
The thickness of the coil prints is not strong enough for so much wire. if your printing these make sure they are 100 % infill otherwise just don't manhandle them be gentle.   

I broke 4 - reprinted with 100 % infill   

The Turbine Blade - I was testing my design with a fan  . It Does work but can be much better,  
I am going to change the Blade  
it will use 3 Blades instead of 6 and will print 1 mm thick sheets for the blades.   

I have added a Pic of where i am so far.  
Going from Thought to product : - designing something and making it is a process. I never saw so many changes coming but until you put it together you wont know.   


# Instructions

I designed this using Autodesk Inventor  
i have a Prusa i3 ( LH 0.2 Nozzle 0.4 PLA 1.75mm)   

Part List  
Base   
Coil Base  (x2)  
Coil Base Cover (x2)  
Turbine  
Rotor  
5mm Carbon Tube (From local RC shop)  
Magnets  30 mm x 5 mm   (x8)  
Magnet Wire 0.28mm  

Making the Coils  
Print the Coil base and the Cover - Glue them together.  
NB : Print the Coils with 100 % infill   
Use a drill to wind the coil then I used clear Nail Polish to coat the winding and put some insulation tape on.  
Cut the Additional piece off (Used to attach to the drill)  
Coil is ready to Go. (See Pics)