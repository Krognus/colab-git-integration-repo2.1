                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2414983
RC Tank  by Staind is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

<h5>At first:</h5>
Unfortunately my English isn´t good, but I would like to write the description in German and English. Please write a message if you see a translation error.

Hello,

I have seen this speed tank (https://www.thingiverse.com/thing:2024364) and was inspired by the concept.
But I wanted to change some things, so I decided to build my own tank. This tank is not compatible with the above speed tank. It has been completely redesigned.

The following parts have changed since the publication:
(You can recognize it at the version number V_X_X)

15.07.2017:
-left_motor_bracket_brushless_V1_1
-left_gearbox_1_V1_1
-left_gearbox_2_V1_1
-right_motor_bracket_brushless_V1_1
-right_gearbox_1_V1_1
-right_gearbox_2_V1_1

03.08.2017:
-540_motor_bracket_V1_1
-new added esc_holder_universal_V1

10.02.2018:
- The cover has been added (https://www.thingiverse.com/thing:2789271)

A small video:
https://youtu.be/3Mv_tDY89Zw

<br>

Hallo,

ich habe bei Thingiverse diesen Speed Tank (https://www.thingiverse.com/thing:2024364) gesehen und war von dem Konzept begeistert. 
Ich wollte aber einige Dinge ändern und so entschied ich mich, einen eigenen Tank zu bauen. Dieser Tank ist mit dem oben genannten Speed Tank nicht kompatibel, da er von Grund auf neu konstruiert wurde.

Ich möchte die Beschreibung gerne auf Deutsch und Englisch erstellen. 
Leider ist mein Englisch alles andere als perfekt. Sollten im Text Fehler sein würde ich mich um eine kleine Nachricht freuen.

Folgende Teile haben sich seit der Veröffentlichung geändert:
(Auch erkennbar an den Versionsstand V_X_X)

15.07.2017:
-left_motor_bracket_brushless_V1_1
-left_gearbox_1_V1_1
-left_gearbox_2_V1_1
-right_motor_bracket_brushless_V1_1
-right_gearbox_1_V1_1
-right_gearbox_2_V1_1

03.08.2017:
-540_motor_bracket_V1_1
-neu hinzugefügt esc_holder_universal_V1

10.02.2018:
- Die Abdeckung wurde hinzugefügt (https://www.thingiverse.com/thing:2789271)


# Documentation / Dokumentation

<h3>General information</h3>
Printing time: approx. 100 hours
Needed filament: about 1.5kg
Printing board: at least 200mm x 200mm
Costs: approx. 150 Euro incl. filament, excl. receiver, remote control and battery. See below for an overview of costs.
<br>

<h5>Allgemeine Informationen</h5>
Druckzeit: ca. 100 Stunden
Benötigtes Filament: ca. 1,5kg
Druckbrett: mindestens 200mm x 200mm
Kosten: ca. 150 Euro inkl. Filament, exkl. Empfänger, Fernsteuerung und Akku. Eine Preisübersicht findet ihr weiter unten.

<br>
<h3>Print setting</h3>
I printed all parts with the following settings.
Material: PLA / PETG
Diameter of the nozzle: 0.4 mm
Layer height: 0.2 mm
Printing speed: 60-80mm / s
Contour: 3
Top layers: 3
Bottom layers: 3
Infill: 30%
Support: no

<h5>Druckeinstellung</h5>
Alle Teile wurden mit folgenden Druckeinstellungen gedruckt
Material: PLA / PETG
Düsendurchmesser: 0,4mm
Schichthöhe: 0.2mm
Druckgeschwindigkeit: 60-80mm/s
Kontur: 3
Geschlossene Deckschichten: 3 
Geschlossene Bodenschichten: 3 
Infill: 30 %
Support: nein

<br>
<h3>Print overview</h3>
Following parts must print multiple times:

 2 x drive_gear_brushless_14_V1
 2 x gear_36_18_V1
 2 x track_drive_wheel_54_V1
 8 x track_wheel_V1
 2 x track_wheel_tension_V1
 96 x track_V1
 2 x logo_V1

In this list everything is summarize. You can also find information about material, printing time and print quantity.

<h5>Druckübersicht</h5>

Folgende Teile müssen mehrmals gedruckt werden:

 2 x drive_gear_brushless_14_V1
 2 x gear_36_18_V1
 2 x track_drive_wheel_54_V1
 8 x track_wheel_V1
 2 x track_wheel_tension_V1
 96 x track_V1
 2 x logo_V1

In folgender Liste ist alles nochmal zusammengefasst. Zudem findet ihr auch Informationen zum Material,zur Druckzeit und Druckmenge.

<img src="http://www.bilder-upload.eu/upload/cf87f1-1537487955.jpg" alt="alt text" />
<a href="http://www.bilder-upload.eu/upload/cf87f1-1537487955.jpg">click to zoom image</a>

<br>
<h3>Ordering overview</h3>
following accessories are required:

4 x M3 nut
98 x M3 lock nut
  8 x M3 screw, length 5mm
  4 x M3 screw, length 20mm
96 x M3 screw, length 45mm
46 x M4 nut
14 x M4 lock nut
18 x M4 screw, length 10mm
22 x M4 screw, length 20mm
  2 x M4 screw, length 35mm
  2 x M4 screw, length 40mm
12 x M4 screw, length 50mm
  4 x M5 lock nut
  4 x bearing 604
24 x  bearing 608
  2 x Sunnysky X2212 980KV Brushless motor
  2 x 20A Emax Simonk Brushless ESC

In this list everything is summarize. You can also find information about costs and where to buy.

<h5>Bestellübersicht</h5>

Zu den gedruckten Teilen wird folgendes Zubehör benötigt:

  4 x M3 Mutter
98 x M3 Stoppmutter
  8 x M3 Schraube, Länge 5mm
  4 x M3 Schraube, Länge 20mm
96 x M3 Schraube, Länge 45mm
46 x M4 Mutter
14 x M4 Stoppmutter
18 x M4 Schraube, Länge 10mm
22 x M4 Schraube, Länge 20mm
  2 x M4 Schraube, Länge 35mm
  2 x M4 Schraube, Länge 40mm
12 x M4 Schraube, Länge 50mm
  4 x M5 Stoppmutter
  4 x Kugellager 604
24 x Kugellager 608
  2 x Sunnysky X2212 980KV Brushless Motor
  2 x 20A Emax Simonk Brushless ESC Regler

In folgender Liste ist alles nochmal zusammengefasst. Zudem findet ihr auch Informationen zum Preis.

<img src="http://www.bilder-upload.eu/upload/d0e1a6-1537488003.jpg" />
<a href="http://www.bilder-upload.eu/upload/d0e1a6-1537488003.jpg">click to zoom image </a>

<br>
<h3>Screw list</h3>

In this list you find information which part need which screws and nuts.

<h5>Schraubentabelle</h5>

Folgend eine Übersicht, aus der ersichtlich ist, welche Schrauben für welche gedruckten Teile benötigt werden. Eine bessere Beschreibung inkl. Bilder folgt in den nächsten Tagen.

<img src="http://www.bilder-upload.eu/upload/134dd3-1537487798.jpg" />
<a href="http://www.bilder-upload.eu/upload/134dd3-1537487798.jpg">click to zoom image</a>

<br>
<h3>Different types of motors</h3>

At the moment you can use 3 different types of motors:

1) (tested) Sunnysky X2212 980KV Brushless Motor (printed gear)

2) (not tested) Brushless Motor with 3,175mm shaft and a max diameter of 28,5mm (960-1000KV)
You need a metal gear module 1 with 14 teeth. (Like this one https://www.voelkner.de/products/115422/Stahl-Zahnrad-14-Z-Modul-1-B3-2.html)

3) (not tested) Brushed or Brushless 540 Motor.
You need a metal gear module 1 with 10-14 teeth. (Like this one https://www.voelkner.de/products/115406/Stahl-Zahnrad-12-Z-Modul-1-B3-2.html)

When you will use the 3rd version you needn´t following things:
-left_motor_bracket_brushless_V1_1
-left_gearbox_1
-left_gearbox_2
-right_motor_bracket_brushless
-right_gearbox_1
-right_gearbox_2
-drive_gear_brushless_14

But you need 2 x 540_motor_bracket_V1.


<h5>Verschiedene Motortypen</h5>

Momentan kann man 3 verschiedene Motortypen verwenden:

1) (getestet) Sunnysky X2212 980KV Brushless Motor (gedrucktes Zahnrad)

2) (nicht getestet) Brushless Motor mit einem 3,175mm Schaft und einem maximalen Durchmesser von 28.5mm (960-1000KV).
Dazu brauch man ein Modul 1 Metal Zahnrad mit 14 Zähnen.
 (https://www.voelkner.de/products/115422/Stahl-Zahnrad-14-Z-Modul-1-B3-2.html)

3) (nicht getestet) Brushed or Brushless 540 Motor.
Dazu brauch man ein Modul 1 Metal Zahnrad mit 10-14 Zähnen.(https://www.voelkner.de/products/115406/Stahl-Zahnrad-12-Z-Modul-1-B3-2.html)

Wenn du die 3te Version verwendest brauchst du folgende Teile nicht drucken:
-left_motor_bracket_brushless_V1_1
-left_gearbox_1
-left_gearbox_2
-right_motor_bracket_brushless
-right_gearbox_1
-right_gearbox_2
-drive_gear_brushless_14

Dafür brauchst du aber 2 x 540_motor_bracket_V1.

<img src="http://www.bilder-upload.eu/upload/7e523e-1501442309.jpg" />
<a href="http://www.bilder-upload.eu/upload/7e523e-1501442309.jpg">click to zoom image</a>

<iframe src="//www.youtube.com/embed/Ufgil4b1P-k" frameborder="0" allowfullscreen></iframe>

<br>
<h3>Post Processing / Nachbearbeitung</h3>

<iframe src="//www.youtube.com/embed/VGz5MzvCxII" frameborder="0" allowfullscreen></iframe>

<br>
<h3>Assembly Instruction / Montageanleitung</h3>

<iframe src="//www.youtube.com/embed/_NUvwd62D9E" frameborder="0" allowfullscreen></iframe>

<br>
<h3>Schematic Diagram / Schaltplan</h3>

<img src="http://www.bilder-upload.eu/upload/6dedf1-1501436911.png" />
<a href="http://www.bilder-upload.eu/upload/6dedf1-1501436911.png">click to zoom image </a>
<br>
<img src="http://www.bilder-upload.eu/upload/e082cc-1518227611.png" />