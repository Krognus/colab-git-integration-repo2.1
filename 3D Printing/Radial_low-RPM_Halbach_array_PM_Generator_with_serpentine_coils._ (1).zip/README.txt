                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1693579
Radial low-RPM Halbach array PM Generator with serpentine coils.  by TanyaAkinora is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This generator is designed for our converter low-potential energy into electricity. 
Also, it can be applied in wind or hydro-generators.
http://www.slideshare.net/bulgakovatanya/argenar
1. Halbach array allows the most efficient use of the energy of the magnetic field of the permanent magnets. There is no need to put the iron disk.
The magnetic field at the outer side of the rotor is much stronger than on the inside.
https://en.wikipedia.org/wiki/Halbach_array
2. The radial design of the magnets and windings.
This allows for a uniform magnetic field and to increase the efficiency of the winding.
The radial design is more efficient than axial  in this case.
3. Serpentine coil.
This type of winding is the best compared to the three-phase winding. But serpentine coil has more difficult to assemble, but it is worth it.
4. 3D printed parts.
You can use any plastic materials for printing details for this generator. But for more powerful generators needed a solid filament.  Otherwise, the rotor can be deformed by a powerful magnet.
3D printing and the principle of combining radial Halbach array PM and serpentine coil allows you to build highly efficient generators (and motors) -like radial and linear.
It is possible to make the generator for a wide range of capacities and sizes - from generators to the Internet of Things (up to 1-2W)  to 5-10 kW generator for local installations. 3D printing can reduce the time and cost of construction of the entire device.


# Print Settings

Printer: prusa i3
Infill: 0,15

Notes: 
Material ABS
Shaft 5mm, 
bearing 625zz.      
PM 15X5X5 mm     
NdFeB N42

Magnets: https://www.indigoinstruments.com/