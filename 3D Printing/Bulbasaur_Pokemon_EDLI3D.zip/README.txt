                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3059107
Bulbasaur, Pokemon EDLI3D by ShadowBons is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Un regalo para la comunidad Gamer y para los amantes de los pokemon, espero que lo disfruten. tambíen está aquí en thingiverse mi squirtle por cierto ;)

# Print Settings

Printer Brand: Creality
Printer: CR-10
Rafts: No
Supports: Yes
Resolution: 0.08

Notes: 
No infill 3, walls i hope you enjoy, join us on our facebook group "EDLI3D"

No tiene relleno, 3 paredes de perimetro, espero que lo disfruten, no olviden unirse a nuestro grupo de impresión EDLI3D

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/68/5f/5d/41/b4/39585394_1782834625087224_356385056098353152_n.jpg)

![Alt text](https://cdn.thingiverse.com/assets/05/4f/af/b9/d4/39607972_1782833065087380_2836246808567480320_n.jpg)

![Alt text](https://cdn.thingiverse.com/assets/71/f4/01/da/25/39628870_1782833328420687_1426212678833012736_n.jpg)

# How I Designed This

Blender

![Alt text](https://cdn.thingiverse.com/assets/b5/7c/33/3f/c7/39500069_1781414748562545_5092763187833470976_n.jpg)