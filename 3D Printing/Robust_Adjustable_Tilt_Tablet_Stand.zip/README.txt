                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:37283
Robust Adjustable Tilt Tablet Stand by inhale3d is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Beefy, adjustable tilt tablet stand.  Now also includes a narrow base choice to fit phones, not just tablets. Designed in ViaCAD.  



Inspired by Thing: http://www.thingiverse.com/thing:31831

# Instructions

I printed and used http://www.thingiverse.com/thing:31831 and thought it was a great design - really fun to put together and looked great.   The main downside was its small size and narrow stance - therefore it had stability issues for Kindle and larger tablets.  Worked fine for iphone and was marginal for an iPad mini.   

So, I decided to start from scratch in ViaCAD and designed an adjustable stand tipping my hat to Thing 31831 and looking at my Chaise Lounge tilt design.  This stand is improved in these ways:  

1) Overall larger scale and beefier structure  

2) Much wider stance for more stable tablet cradle  

3) Easy to print   

4) No long screws are needed.  Many fewer fasteners required.  

5) Easy hardware requirements - only 4 M5 x 0.8 x 16mm socket head bolts and 4 M5 x .8 nuts are used  (black socket head bolts look cool.)  

6) Provided ViaCAD source files for your tinkering pleasure (any of the .vc3 files are the source files)  

7) Cradle is deeper to accommodate tablets without removing their cases  


3D Print the 3 STL files:  

<b>Base: tablet-stand-base.stl</b> 

<b>Braces: tablet-angle-brace2.stl</b>  

<b>Uprights: tablet-stand-uprights-v2.stl</b>  

<b>Cross-bars: tablet-stand-cross-bars-x4.stl</b>  Optional cross-bars that can be used on the hook arms to create a flat base for <i>narrow</i> devices to rest on.  Same cross bars fit across the top of the arms to provide a back for narrow devices.   It's easiest to 'glue' these onto the arms using Acetone on both the arm and the inner slot are of the cross-bar.  The Acetone will dissolve the plastic and when the cross-bar and arm is in contact with each other, the plastics will quickly bond.  Alternatively, simply super-glue the cross-bar slot area to the arm wherever you prefer.

For the braces and uprights, there is a left and a right part included in the STL.  

I used a LulzBot AO-100 for the print, 0.5mm nozzle, 0.3mm layer height, 1 vertical shell.  The Slic3r INI file I used for the test print can be downloaded at the left - filename: Inhale3D-tablet-stand.ini.  That'll give you a head start on a print config.  

Assemble the stand as shown using 4 M5x16mm bolts and nuts.  The nuts press in to the base and braces from the inside joints.  It's easiest to use either channel lock pliers or vice-grips adjusted with a wide jaw - need wide jaws to squeeze it into place so it's flat.  The nuts are a very tight fit and can't easily be pressed in by hand, but this makes for very solid-feeling joints.  

(ViaCAD 2D3D 8 for design, Strata Design 3D SE used for raytraced renderings shown, LulzBot AO-100 for test prints, Slic3r 0.9.7 for gcode.)   


<b>Updated 12/15/12</b> to open nut cutouts to make it somewhat easier to press in M5 nuts.  

<b>Updated 1/8/12</b> to beef up spars in base so there is less flex.  replaced stl and vc3 files for base.  

<b>Updated 7/15/18</b>  Added another base that's narrower so if you want to build a stand like this for your phone instead of tablet, that's the base to use.  Otherwise, all the other parts are the same.

<b>Updated 7/31/18</b> Added optional cross-bars that can form different bracing configurations for various types of devices including devices narrower than the arm's stance.] 

- Landon Cox