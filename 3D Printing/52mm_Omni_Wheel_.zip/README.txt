                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2599926
52mm Omni Wheel  by Chimes_Industries is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

First off, let me please ask that if you like these designs and find them useful please do like, follow and share my content. And if you have any ideas or concepts to modify the content I would love to hear!

I am loving making these omni wheels, and this is my most successful one thus far. Ideal for grippier surfaces like felt, cloth, vinyl etc. The plastic wheels have lots of trouble with finding grip on hard, smooth surfaces. 

These fit the 3mm D-shaft of the Pololu micro-metal geared motors. They are a snug fit the first time round, though after a good push they fit very well. There is also a location for a M3 nut and grub screw if a tighter fit is necessary. Each of the eight rollers is secured in place using M3 nut and bolts. Micro-metal geared motor mount found here https://www.thingiverse.com/thing:2543948

When printing be sure to use a relatively thin wall thickness to ensure you can print the thinner sections. This requires supports (touching build plate only). 

Let me know what you think :)


6th June 2018 Update: Added IGES and STEP files

James.

# Print Settings

Printer: Kossel Mini
Rafts: No
Supports: Yes
Resolution: 0.05 - 0.2
Infill: 22%

Notes: 
Be sure to keep the wall thickness low when printing. Check your GCODE in a slicer/viewer to ensure the walls are printing throughout the model.